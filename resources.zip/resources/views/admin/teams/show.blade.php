@extends('layouts.admin.teams')

@section('title')
    <title>{{$team->name}} - Legalpedia</title>
@endsection

@section('content')
<script src='https://{{url()->current()}}/external_api.js'></script>
    <style>
        .header-img-top {
            height: 300px !important;
            object-fit: cover !important;
        }
        .text-green-0{
            color: #32E017 !important;
        }
        .h-2{
            height: 25px;
        }
        .w-2{
            width: 25px;
        }
        .cursor {
            cursor: pointer;
        }
        .modal-content {
            width: 100% !important;
            height: auto !important;
        }
    </style>
    <div class="header">
        <img src="{{$team->photo}}" class="header-img-top" alt="...">
        <div class="container-fluid">
            @include('elements.notifications')
            <div class="header-body mt-n5 mt-md-n6">
                <div class="row align-items-end">
                    <div class="col-auto">
                        <div class="avatar avatar-xxl header-avatar-top">
                            <img src="{{$team->photo}}" alt="..." class="avatar-img rounded border border-4 border-body">
                        </div>
                    </div>
                    <div class="col mb-3 ms-n3 ms-md-n2">
                        <h6 class="header-pretitle">
                            <a href="{{url('admin/teams')}}" class="text-color mb-6"><i class="fe fe-arrow-left mr-2"></i> Back to Teams</a>
                        </h6>
                        <h1 class="header-title">
                            {{$team->name}}
                        </h1>
                        
                    </div>
                    <div class="col-12 col-md-auto mt-2 mt-md-0 mb-md-3 d-flex">
                        <span class="pt-2 mr-4">
                            @if ($rating_count > 0)
                                <a href="#reviews"><small>{{number_format($rating_count)}} . {{getRating($rating)}} </small></a>
                            @else
                                <small class="text-muted">No rating</small> 
                            @endif
                        </span>
                        @if(Auth::user()->role->name == 'Admin')
                            <span class="pt-2 mr-4">
                                <a href="#" data-bs-target="#rate" data-bs-toggle="modal"><i class="mdi mdi-star"></i> <i class="mdi mdi-star"></i> Rate this Team</a></span>
                            </span>
                        @elseif(Auth::user()->id !== $team->user_id)
                            @if(isset($team_member->user_id))
                                @if(Auth::user()->id == $team_member->user_id)
                                    <span class="pt-2 ml-2 mr-4">
                                        <a href="#" data-bs-target="#rate" data-bs-toggle="modal"><i class="mdi mdi-star"></i> <i class="mdi mdi-star"></i> Rate this Team</a></span>
                                    </span>
                                @endif
                            @endif
                        @endif
                        @if(Auth::user()->id == $team->user_id)
                            <a data-bs-toggle="modal" data-bs-target="#startMeeting" class="btn-primary text-white btn"><i class="mdi mdi-play"></i> Start a Meeting</a>
                        @elseif(Auth::user()->id !== $team->user_id)
                            @if(empty($send_request))
                                <form action="{{route('send.request')}}" method="POST">
                                    @csrf
                                    <input type="hidden" name="send_request" value="1">
                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                    <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                    <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                        <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                    </button>
                                </form>
                            @elseif($send_request->send_request == 0)
                                <form action="{{route('send.request')}}" method="POST">
                                    @csrf
                                    <input type="hidden" name="send_request" value="1">
                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                    <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                    <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                        <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                    </button>
                                </form>
                                @elseif($send_request->send_request == 1 && $send_request->approve_request == 0)
                                <a style="cursor: not-allowed; text-align: center" class="px-5 bg-padding py-3 d-block d-md-inline-block font-medium leading-5 text-gray-400 transition-colors duration-150 bg-gray-100 hover:bg-gray-100 dark:bg-gray-700 border border-transparent rounded-lg">Request Sent</a>
                                @elseif($send_request->send_request == 1 && $send_request->approve_request == 1)
                            @endif
                        @endif
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="col">
                        <ul class="nav nav-tabs nav-overflow header-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" id="feeds-tab" data-toggle="tab" href="#feeds" role="tab" aria-controls="feeds" aria-selected="true">
                                    Team Feeds
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="saved-tab" data-toggle="tab" href="#saved" role="tab" aria-controls="saved" aria-selected="false">
                                    Saved Posts
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="members-tab" data-toggle="tab" href="#members" role="tab" aria-controls="members" aria-selected="false">
                                    Members
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="review-tab" data-toggle="tab" href="#review" role="tab" aria-controls="review" aria-selected="false">
                                    Reviews
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="resources-tab" data-toggle="tab" href="#resources" role="tab" aria-controls="resources" aria-selected="false">
                                    Shared Resources
                                </a>
                            </li>
                            @if(Auth::user()->id == $team->user_id)
                                <li class="nav-item">
                                    <a class="nav-link" id="settings-tab" data-toggle="tab" href="#settings" role="tab" aria-controls="settings" aria-selected="false">
                                        Settings
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="tab-content" id="wizardSteps">
            <div class="tab-pane fade show active" id="feeds" role="tabpanel" aria-labelledby="feeds-tab">
                <div class="row">
                    <div class="col-12 col-xl-8">
                        @if(Auth::user()->id == $team->user_id)
                            <div class="mb-4">
                                <form action="{{route('show.team', $team->id)}}" method="GET" class="d-flex">
                                    <div class="input-group input-group-lg input-group-merge input-group-reverse mr-3">
                                        <input class="form-control list-search" name="search_post" type="text" id="searchBar" placeholder="Search Posts" style="height: 50px">
                                        <div class="input-group-text">
                                            <span class="fe fe-search"></span>
                                        </div>
                                    </div>
                                    <button id="searchPostBtn" disabled class="btn button_load text-white btn-sm btn-primary p-2 px-3" onclick="this.classList.toggle('button--loading1')">
                                        <span class="button__text"> Search</span>
                                    </button>
                                </form>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <form action="{{route('post.comment')}}" method="POST" enctype="multipart/form-data">
                                        @csrf
                                        <div class="input-group input-group-lg input-group-flush input-group-merge">
                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                            <input type="hidden" name="team_id" value="{{$team->id}}">
                                            <textarea name="comment_body" id="commentBody" class="form-control form-control-flush" data-autosize rows="1" placeholder="Create posts and share files to this team"></textarea>
                                            <div class="input-group-text">
                                                <a class="text-reset me-3" style="cursor: pointer" id="attach" onclick="showFile()" data-bs-toggle="tooltip" title="Attach file">
                                                    <i class="fe fe-paperclip"></i>
                                                </a>
                                                <a class="text-reset me-3" style="cursor: pointer; display:none" id="remove" onclick="removeFile()" data-bs-toggle="tooltip" title="Remove file">
                                                    <i class="mdi mdi-close"></i>
                                                </a>
                                                <button type="submit" disabled onclick="this.classList.toggle('button--loading')" id="remove-1" class="btn button_load text-white btn-primary">
                                                    <span class="button__text"><i class="mdi mdi-check"></i> Post</span>
                                                </button>
                                            </div>
                                        </div>
                                        <div class="file-input" id="file_input" style="display: none">
                                            <div class="form-group">
                                                <label class="form-label mb-1">
                                                    Select File type
                                                </label>
                                                <select name="file_type" id="file_type" class="form-select" onchange="showDiv('PDF', 'DOC', this)">
                                                    <option value="image">Image</option>
                                                    <option value="video">Video</option>
                                                    <option value="PDF" data_type="files">PDF</option>
                                                    <option value="DOC" data_type="files">DOC</option>
                                                    {{-- <option value="ZIP" data_type="files">ZIP</option> --}}
                                                    {{-- <option value="RAR" data_type="files">RAR</option> --}}
                                                </select>
                                            </div>
                                            <div class="form-group file_name" id="PDF" style="display: none">
                                                <label class="form-label mb-1">
                                                    File Name
                                                </label>
                                                <input type="text" name="pdf_name" class="form-control">
                                            </div>
                                            <div class="form-group file_name" id="DOC" style="display: none">
                                                <label class="form-label mb-1">
                                                    File Name
                                                </label>
                                                <input type="text" name="doc_name" class="form-control">
                                            </div>
                                            {{-- <div class="form-group file_name" id="ZIP" style="display: none">
                                                <label class="form-label mb-1">
                                                    File Name
                                                </label>
                                                <input type="text" name="zip_name" class="form-control">
                                            </div>
                                            <div class="form-group file_name" id="RAR" style="display: none">
                                                <label class="form-label mb-1">
                                                    File Name
                                                </label>
                                                <input type="text" name="rar_name" class="form-control">
                                            </div> --}}
                                            <div class="form-group">
                                                <label for="actual-btn" style="cursor: pointer" class="w-100 p-6 w-full text-center px-4 py-6 bg-white rounded-md border border-blue cursor-pointer hover:bg-purple-600 dark:bg-gray-700 hover:text-white text-gray-600 dark:text-gray-200 ease-linear transition-all duration-150">
                                                    <i class="mdi mdi-cloud-upload icon-size"></i>
                                                    <span class="mt-2 text-base text-lg leading-normal">Select a file</span>
                                                    <input type="file" name="file" id="actual-btn" class="hidden"><br>
                                                    <h2 class="text-lg" id="file-chosen">No file chosen</h2>
                                                </label>
                                            </div>
                                            <button type="submit" disabled onclick="this.classList.toggle('button--loading')" id="show-1" style="display: none; float: right" class="btn button_load text-white btn-primary">
                                                <span class="button__text"><i class="mdi mdi-check"></i> Post</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        @else
                            @if($send_request)
                                @if($send_request->send_request == 1 && $send_request->approve_request == 1)
                                    <div class="mb-4">
                                        <form action="{{route('show.team', $team->id)}}" method="GET" class="d-flex">
                                            <div class="input-group input-group-lg input-group-merge input-group-reverse mr-3">
                                                <input class="form-control list-search" name="search_post" id="searchBar" type="text" placeholder="Search Posts" style="height: 50px">
                                                <div class="input-group-text">
                                                    <span class="fe fe-search"></span>
                                                </div>
                                            </div>
                                            <button id="searchPostBtn" disabled class="btn button_load text-white btn-sm btn-primary p-2 px-3" onclick="this.classList.toggle('button--loading1')">
                                                <span class="button__text"> Search</span>
                                            </button>
                                        </form>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                            <form action="{{route('post.comment')}}" method="POST" enctype="multipart/form-data">
                                                @csrf
                                                <div class="input-group input-group-lg input-group-flush input-group-merge">
                                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                                    <textarea name="comment_body" id="commentBody" class="form-control form-control-flush" data-autosize rows="1" placeholder="Create posts and share files to this team"></textarea>
                                                    <div class="input-group-text">
                                                        <a class="text-reset me-3" style="cursor: pointer" id="attach" onclick="showFile()" data-bs-toggle="tooltip" title="Attach file">
                                                            <i class="fe fe-paperclip"></i>
                                                        </a>
                                                        <a class="text-reset me-3" style="cursor: pointer; display:none" id="remove" onclick="removeFile()" data-bs-toggle="tooltip" title="Remove file">
                                                            <i class="mdi mdi-close"></i>
                                                        </a>
                                                        <button type="submit" disabled onclick="this.classList.toggle('button--loading')" id="remove-1" class="btn button_load text-white btn-primary">
                                                            <span class="button__text"><i class="mdi mdi-check"></i> Post</span>
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="file-input" id="file_input" style="display: none">
                                                    <div class="form-group">
                                                        <label class="form-label mb-1">
                                                            Select File type
                                                        </label>
                                                        <select name="file_type" id="file_type" class="form-select" onchange="showDiv('PDF', 'DOC', this)">
                                                            <option value="image">Image</option>
                                                            <option value="video">Video</option>
                                                            <option value="PDF" data_type="files">PDF</option>
                                                            <option value="DOC" data_type="files">DOC</option>
                                                            {{-- <option value="ZIP" data_type="files">ZIP</option>
                                                            <option value="RAR" data_type="files">RAR</option> --}}
                                                        </select>
                                                    </div>
                                                    <div class="form-group file_name" id="PDF" style="display: none">
                                                        <label class="form-label mb-1">
                                                            File Name
                                                        </label>
                                                        <input type="text" name="pdf_name" class="form-control">
                                                    </div>
                                                    <div class="form-group file_name" id="DOC" style="display: none">
                                                        <label class="form-label mb-1">
                                                            File Name
                                                        </label>
                                                        <input type="text" name="doc_name" class="form-control">
                                                    </div>
                                                    {{-- <div class="form-group file_name" id="ZIP" style="display: none">
                                                        <label class="form-label mb-1">
                                                            File Name
                                                        </label>
                                                        <input type="text" name="zip_name" class="form-control">
                                                    </div>
                                                    <div class="form-group file_name" id="RAR" style="display: none">
                                                        <label class="form-label mb-1">
                                                            File Name
                                                        </label>
                                                        <input type="text" name="rar_name" class="form-control">
                                                    </div> --}}
                                                    <div class="form-group">
                                                        <label for="actual-btn" style="cursor: pointer" class="w-100 p-6 w-full text-center px-4 py-6 bg-white rounded-md border border-blue cursor-pointer hover:bg-purple-600 dark:bg-gray-700 hover:text-white text-gray-600 dark:text-gray-200 ease-linear transition-all duration-150">
                                                            <i class="mdi mdi-cloud-upload icon-size"></i>
                                                            <span class="mt-2 text-base text-lg leading-normal">Select a file</span>
                                                            <input type="file" name="file" id="actual-btn" class="hidden"><br>
                                                            <h2 class="text-lg" id="file-chosen">No file chosen</h2>
                                                        </label>
                                                    </div>
                                                    <button type="submit" disabled onclick="this.classList.toggle('button--loading')" id="show-1" style="display: none; float: right" class="btn button_load text-white btn-primary">
                                                        <span class="button__text"><i class="mdi mdi-check"></i> Post</span>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                @endif
                            @endif
                        @endif
                        @if(count($comments) > 0)
                            @if(!empty($comment))
                                <div class="card">
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <div class="row align-items-center">
                                                <div class="col-auto">
                                                    <span class="avatar avatar-sm">
                                                        <?php $user = App\Models\User::where('id', @$comment->user_id)->first(); ?>
                                                        @if($user->photo)
                                                            <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                            @else
                                                            <div class="initials">
                                                                <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                            </div>
                                                        @endif
                                                    </span>
                                                </div>
                                                <div class="col ms-n2">
                                                    <h4 class="mb-1">
                                                        <a href="{{route('user.profile', $user->id)}}">
                                                            {{$user->name}}
                                                        </a>
                                                    </h4>
                                                <p class="card-text small text-muted">
                                                    <span class="fe fe-clock"></span>
                                                    @if($comment->created_at < $comment->updated_at)
                                                            Edited {{\Carbon\Carbon::parse($comment->updated_at)->toFormattedDateString()}}
                                                            @else
                                                            Posted {{\Carbon\Carbon::parse($comment->created_at)->toFormattedDateString()}}
                                                        @endif
                                                    </p>
                                                </div>
                                                <div class="col-auto d-flex">
                                                    @if(Auth::user()->id == $team->user_id)
                                                        @if($comment->pinned_post == 0)
                                                            <div class="mr-3">
                                                                <form action="{{route('update.comment')}}" method="POST">
                                                                    {{ csrf_field() }}
                                                                    {{ method_field('patch') }}
                                                                    <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                    <input type="hidden" name="pinned_post" value="1">
                                                                    <button type="submit" name="pin_post" class="custom-button text-color">
                                                                        <i class="mdi mdi-pin"></i> Pin post
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        @elseif($comment->pinned_post == 1)
                                                            <div class="mr-3">
                                                                <form action="{{route('update.comment')}}" method="POST">
                                                                    {{ csrf_field() }}
                                                                    {{ method_field('patch') }}
                                                                    <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                    <input type="hidden" name="pinned_post" value="0">
                                                                    <button type="submit" name="unpin_post" onmouseover="unpin(this)" onmouseout="pin(this)" class="custom-button text-success">
                                                                        <i class="mdi mdi-pin"></i> Pinned
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        @endif
                                                    @else
                                                        @if($comment->pinned_post == 1)
                                                            <div class="mr-3">
                                                                <span class="custom-button text-success">
                                                                    <i class="mdi mdi-pin"></i> Pinned
                                                                </span>
                                                            </div>
                                                        @endif
                                                    @endif
                                                    @if($comment->user_id == Auth::user()->id)
                                                        @if(empty($comment->article_id))
                                                            <div class="dropdown">
                                                                <a href="#" class="dropdown-ellipses dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="fe fe-more-vertical"></i>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a style="cursor: pointer" data-bs-toggle="modal" onclick='showEditPost("{{$comment->comment_body}}", "{{$comment->id}}")' class="dropdown-item">
                                                                        <i class="mdi mdi-pencil mr-2"></i> Edit
                                                                    </a>
                                                                    <form action="/admin/teams/comment/{{$comment->id}}" method="POST">
                                                                        {{ csrf_field() }}
                                                                        {{ method_field('DELETE') }}
                                                                        <button type="submit" name="submit" onclick="return deletePost();" class="dropdown-item">
                                                                            <i class="fe fe-trash mr-2"></i>Delete
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        @endif
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <p class="mb-4">
                                            @if($comment->article_id)
                                                @php
                                                    $body = json_decode($comment->comment_body)
                                                @endphp
                                                <p>{!! $body[0] !!}</p>
                                                <p>{!! $body[1] !!}</p>
                                                <p><a href="{{$body[2]}}" class="text-color"><u>View full article <i class="fe fe-arrow-right"></i></u></a></p>
                                            @elseif($comment->form_precedence_id)
                                                @php
                                                    $body = json_decode($comment->comment_body)
                                                @endphp
                                                <p>{!! $body[0] !!}</p>
                                                <p>{!! $body[1] !!}</p>
                                                <p><a href="{{$body[2]}}" class="text-color"><u>View full form <i class="fe fe-arrow-right"></i></u></a></p>
                                            @else
                                                {!! $comment->comment_body !!}
                                            @endif
                                        </p>
                                        <p class="mb-4 text-center">
                                            @if($send_request)
                                                @if($send_request->send_request == 1 && $send_request->approve_request == 1)
                                                    @if($comment->file_type == 'image')
                                                        <img src="{{$comment->file}}" class="img-fluid rounded">
                                                        @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                        @elseif($comment->file_type == 'PDF')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                                {{$comment->pdf_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'DOC')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                                {{$comment->doc_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'ZIP')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                                {{$comment->zip_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'RAR')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                                {{$comment->rar_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    @endif
                                                    @else
                                                    @if($comment->file_type == 'image')
                                                        <img src="{{$comment->file}}" class="img-fluid rounded">
                                                        @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                        @elseif($comment->file_type == 'PDF')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                                {{$comment->pdf_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'DOC')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                                {{$comment->doc_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'ZIP')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                                {{$comment->zip_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'RAR')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                                {{$comment->rar_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    @endif
                                                @endif
                                                @else
                                                @if($comment->file_type == 'image')
                                                    <img src="{{$comment->file}}" class="img-fluid rounded">
                                                    @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                    @elseif($comment->file_type == 'PDF')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                            {{$comment->pdf_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'DOC')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                            {{$comment->doc_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'ZIP')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                            {{$comment->zip_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'RAR')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                            {{$comment->rar_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                @endif
                                            @endif
                                        </p>
                                        @foreach($comment->comment_replies as $comment_reply)
                                            <div class="comment mt-4 mb-4">
                                                <div class="row">
                                                    <div class="col-auto">
                                                        <span class="avatar avatar-sm">
                                                            <?php $user = App\Models\User::where('id', $comment_reply->user_id)->first(); ?>
                                                            @if($user->photo)
                                                                <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                                @else
                                                                <div class="initials">
                                                                    <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                                </div>
                                                            @endif
                                                        </span>
                                                    </div>
                                                    <div class="col ms-n2">
                                                        <div class="comment-body">
                                                            <div class="row">
                                                                <div class="col">
                                                                    <h5 class="comment-title">
                                                                        <a href="{{route('user.profile', $user->id)}}">
                                                                            {{$user->name}}
                                                                        </a>
                                                                    </h5>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <time class="comment-time">
                                                                        {{\Carbon\Carbon::parse($comment_reply->created_at)->toFormattedDateString()}}
                                                                    </time>
                                                                </div>
                                                            </div>
                                                            <p class="comment-text">
                                                                {{$comment_reply->comment_reply_body}}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                        @if($send_request)
                                            @if($send_request->send_request == 1 && $send_request->approve_request == 1)
                                                <div class="row justify-content-between">
                                                    <div class="col">
                                                        <div class="d-flex">
                                                            <span class="mr-4">
                                                                <form id="like-form">
                                                                    <input type="hidden" name="user_id" id="user-id" value="{{Auth::user()->id}}">
                                                                    <input type="hidden" name="comment_id" id="comment-id" value="{{$comment->id}}">
                                                                    <input type="hidden" name="team_id" id="team-id" value="{{$team->id}}">
                                                                    @php
                                                                        $likes = App\Models\Like::where('comment_id', $comment->id)->get();
                                                                        $user_has_liked = App\Models\Like::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->where('like', 1)->first();
                                                                        $user_has_unliked = App\Models\Like::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->where('like', 0)->first();
                                                                        $user_has_not_liked = App\Models\Like::where('comment_id', $comment->id)->first();
                                                                        $like_count = App\Models\Like::where('comment_id', $comment->id)->where('like', 1)->count();
                                                                    @endphp
                                                                    @if(count($likes) > 0)
                                                                        @if($user_has_liked)
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" style="display: none" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        @elseif($user_has_unliked)
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}')"></i></h1>
                                                                        @elseif($user_has_not_liked)
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        @endif
                                                                    @else
                                                                        <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                    @endif
                                                                </form>
                                                                <span id="like-div{{$comment->id}}">
                                                                    <small id="like-no{{$comment->id}}" class="text-color">{{$like_count}}</small>
                                                                </span>
                                                            </span>
                                                            <span class="mr-4">
                                                                <h1><i class="mdi mdi-comment-text-multiple"></i></h1>
                                                                @php
                                                                    $comment_reply_count = App\Models\CommentReply::where('comment_id', $comment->id)->count();
                                                                @endphp
                                                                <small class="text-pink">{{$comment_reply_count}}</small>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto">
                                                        <div class="d-flex text-end">
                                                            @php
                                                                $saved_post = App\Models\SavedPost::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->first();
                                                            @endphp
                                                            @if(isset($saved_post) && !empty($saved_post))
                                                                @if($saved_post->status == 0)
                                                                    <span>
                                                                        <form action="{{route('save.post')}}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                            <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                            <input type="hidden" name="status" value="1">
                                                                            <button type="submit" name="unpin_post" class="custom-button">
                                                                                <h1><i class="fe fe-bookmark"></i></h1>
                                                                                <small>Save</small>
                                                                            </button>
                                                                        </form>
                                                                    </span>
                                                                @elseif($saved_post->status == 1)
                                                                    <span>
                                                                        <form action="{{route('save.post')}}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                            <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                            <input type="hidden" name="status" value="0">
                                                                            <button type="submit" class="custom-button text-success">
                                                                                <h1><i class="fe fe-bookmark"></i></h1>
                                                                                <small>Saved</small>
                                                                            </button>
                                                                        </form>
                                                                    </span>
                                                                @endif
                                                            @else
                                                                <span>
                                                                    <form action="{{route('save.post')}}" method="POST">
                                                                        @csrf
                                                                        <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                        <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                        <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                        <input type="hidden" name="status" value="1">
                                                                        <button type="submit" class="custom-button">
                                                                            <h1><i class="fe fe-bookmark"></i></h1>
                                                                            <small>Save</small>
                                                                        </button>
                                                                    </form>
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr>
                                                <form class="mt-1" action="{{route('reply.comment')}}" method="POST">
                                                    @csrf
                                                    <div class="row">
                                                        <div class="col-auto">
                                                            <div class="avatar avatar-sm">
                                                                {{-- <img src="{{Auth::user()->photo}}" alt="{{Auth::user()->name}}" class="avatar-img rounded-circle"> --}}
                                                                @if(Auth::user()->photo)
                                                                    <img src="{{Auth::user()->photo}}" class="avatar-img rounded-circle" alt="{{Auth::user()->name}}">
                                                                    @else
                                                                    <div class="initials">
                                                                        <span>{{Str::limit(Auth::user()->name, 1, '')}}{{Str::limit(Auth::user()->surname, 1, '')}}</span>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="col ms-n2">
                                                            <label class="visually-hidden">Leave a comment...</label>
                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                            <textarea name="comment_reply_body" id="commentReply{{$comment->id}}" class="form-control form-control-flush" onkeyup="commentPost('commentReply{{$comment->id}}', 'commentReplyBtn{{$comment->id}}')" data-autosize rows="1" placeholder="Leave a comment"></textarea>
                                                        </div>
                                                        <div class="col-auto align-self-end">
                                                            <div class="text-muted mb-2">
                                                                <button type="submit" disabled id="commentReplyBtn{{$comment->id}}" name="reply" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white btn-primary">
                                                                    <span class="button__text"><i class="mdi mdi-check"></i> Comment</span>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            @endif
                                        @endif
                                    </div>
                                </div>
                            @endif
                            @foreach($comments as $comment)
                                <div class="card">
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <div class="row align-items-center">
                                                <div class="col-auto">
                                                    <span class="avatar avatar-sm">
                                                        <?php $user = App\Models\User::where('id', $comment->user_id)->first(); ?>
                                                        @if($user->photo)
                                                            <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                            @else
                                                            <div class="initials">
                                                                <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                            </div>
                                                        @endif
                                                    </span>
                                                </div>
                                                <div class="col ms-n2">
                                                    <h4 class="mb-1">
                                                        <a href="{{route('user.profile', $user->id)}}">
                                                            {{$user->name}}
                                                        </a>
                                                    </h4>
                                                   <p class="card-text small text-muted">
                                                       <span class="fe fe-clock"></span>
                                                       @if($comment->created_at < $comment->updated_at)
                                                            Edited {{\Carbon\Carbon::parse($comment->updated_at)->toFormattedDateString()}}
                                                            @else
                                                            Posted {{\Carbon\Carbon::parse($comment->created_at)->toFormattedDateString()}}
                                                        @endif
                                                    </p>
                                                </div>
                                                <div class="col-auto d-flex">
                                                    @if(Auth::user()->id == $team->user_id)
                                                        <div class="mr-3">
                                                            <form action="{{route('update.comment')}}" method="POST">
                                                                {{ csrf_field() }}
                                                                {{ method_field('patch') }}
                                                                <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                <input type="hidden" name="pinned_post" value="1">
                                                                <button type="submit" name="pin_post" class="custom-button text-color">
                                                                    <i class="mdi mdi-pin"></i> Pin post
                                                                </button>
                                                            </form>
                                                        </div>
                                                    @endif
                                                    @if($comment->user_id == Auth::user()->id)
                                                        @if(empty($comment->article_id))
                                                                <div class="dropdown">
                                                                    <a href="#" class="dropdown-ellipses dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        <i class="fe fe-more-vertical"></i>
                                                                    </a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <a style="cursor: pointer" data-bs-toggle="modal" onclick='showEditPost("{{$comment->comment_body}}", "{{$comment->id}}")' class="dropdown-item">
                                                                            <i class="mdi mdi-pencil mr-2"></i> Edit
                                                                        </a>
                                                                        <form action="/admin/teams/comment/{{$comment->id}}" method="POST">
                                                                            {{ csrf_field() }}
                                                                            {{ method_field('DELETE') }}
                                                                            <button type="submit" name="submit" onclick="return deletePost();" class="dropdown-item">
                                                                                <i class="fe fe-trash mr-2"></i>Delete
                                                                            </button>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                        @endif
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <p class="mb-4">
                                            @if($comment->article_id)
                                                @php
                                                    $body = json_decode($comment->comment_body)
                                                @endphp
                                                <p>{!! $body[0] !!}</p>
                                                <p>{!! $body[1] !!}</p>
                                                <p><a href="{{$body[2]}}" class="text-color"><u>View full article <i class="fe fe-arrow-right"></i></u></a></p>
                                            @elseif($comment->form_precedence_id)
                                                @php
                                                    $body = json_decode($comment->comment_body)
                                                @endphp
                                                <p>{!! $body[0] !!}</p>
                                                <p>{!! $body[1] !!}</p>
                                                <p><a href="{{$body[2]}}" class="text-color"><u>View full form <i class="fe fe-arrow-right"></i></u></a></p>
                                            @else
                                                {!! $comment->comment_body !!}
                                            @endif
                                        </p>
                                        <p class="mb-4 text-center">
                                            @if($send_request)
                                                @if($send_request->send_request == 1 && $send_request->approve_request == 1)
                                                    @if($comment->file_type == 'image')
                                                        <img src="{{$comment->file}}" class="img-fluid rounded">
                                                        @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                        @elseif($comment->file_type == 'PDF')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                                {{$comment->pdf_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'DOC')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                                {{$comment->doc_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'ZIP')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                                {{$comment->zip_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'RAR')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                                {{$comment->rar_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    @endif
                                                    @else
                                                    @if($comment->file_type == 'image')
                                                        <img src="{{$comment->file}}" class="img-fluid rounded">
                                                        @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                        @elseif($comment->file_type == 'PDF')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                                {{$comment->pdf_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'DOC')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                                {{$comment->doc_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'ZIP')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                                {{$comment->zip_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'RAR')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                                {{$comment->rar_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    @endif
                                                @endif
                                                @else
                                                @if($comment->file_type == 'image')
                                                    <img src="{{$comment->file}}" class="img-fluid rounded">
                                                    @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                    @elseif($comment->file_type == 'PDF')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                            {{$comment->pdf_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'DOC')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                            {{$comment->doc_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'ZIP')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                            {{$comment->zip_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'RAR')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                            {{$comment->rar_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                @endif
                                            @endif
                                        </p>
                                        @foreach($comment->comment_replies as $comment_reply)
                                            <div class="comment mt-4 mb-4">
                                                <div class="row">
                                                    <div class="col-auto">
                                                        <span class="avatar avatar-sm">
                                                            <?php $user = App\Models\User::where('id', $comment_reply->user_id)->first(); ?>
                                                            @if($user->photo)
                                                                <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                                @else
                                                                <div class="initials">
                                                                    <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                                </div>
                                                            @endif
                                                        </span>
                                                    </div>
                                                    <div class="col ms-n2">
                                                        <div class="comment-body">
                                                            <div class="row">
                                                                <div class="col">
                                                                    <h5 class="comment-title">
                                                                        <a href="{{route('user.profile', $user->id)}}">
                                                                            {{$user->name}}
                                                                        </a>
                                                                    </h5>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <time class="comment-time">
                                                                        {{\Carbon\Carbon::parse($comment_reply->created_at)->toFormattedDateString()}}
                                                                    </time>
                                                                </div>
                                                            </div>
                                                            <p class="comment-text">
                                                                {{$comment_reply->comment_reply_body}}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                        @if($send_request)
                                            @if($send_request->send_request == 1 && $send_request->approve_request == 1)
                                                <div class="row justify-content-between">
                                                    <div class="col">
                                                        <div class="d-flex">
                                                            <span class="mr-4">
                                                                <form id="like-form">
                                                                    <input type="hidden" name="user_id" id="user-id" value="{{Auth::user()->id}}">
                                                                    <input type="hidden" name="comment_id" id="comment-id" value="{{$comment->id}}">
                                                                    <input type="hidden" name="team_id" id="team-id" value="{{$team->id}}">
                                                                    @php
                                                                        $likes = App\Models\Like::where('comment_id', $comment->id)->get();
                                                                        $user_has_liked = App\Models\Like::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->where('like', 1)->first();
                                                                        $user_has_unliked = App\Models\Like::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->where('like', 0)->first();
                                                                        $user_has_not_liked = App\Models\Like::where('comment_id', $comment->id)->first();
                                                                        $like_count = App\Models\Like::where('comment_id', $comment->id)->where('like', 1)->count();
                                                                    @endphp
                                                                    @if(count($likes) > 0)
                                                                        @if($user_has_liked)
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" style="display: none" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        @elseif($user_has_unliked)
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}')"></i></h1>
                                                                        @elseif($user_has_not_liked)
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        @endif
                                                                    @else
                                                                        <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="like-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="unlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'unlike-btn{{$comment->id}}', 'like-btn{{$comment->id}}', 'like-div{{$comment->id}}', 'like-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                    @endif
                                                                </form>
                                                                <span id="like-div{{$comment->id}}">
                                                                    <small id="like-no{{$comment->id}}" class="text-color">{{$like_count}}</small>
                                                                </span>
                                                            </span>
                                                            <span class="mr-4">
                                                                <h1><i class="mdi mdi-comment-text-multiple"></i></h1>
                                                                @php
                                                                    $comment_reply_count = App\Models\CommentReply::where('comment_id', $comment->id)->count();
                                                                @endphp
                                                                <small class="text-pink">{{$comment_reply_count}}</small>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto">
                                                        <div class="d-flex text-end">
                                                            @php
                                                                $saved_post = App\Models\SavedPost::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->first();
                                                            @endphp
                                                            @if(isset($saved_post) && !empty($saved_post))
                                                                @if($saved_post->status == 0)
                                                                    <span>
                                                                        <form action="{{route('save.post')}}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                            <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                            <input type="hidden" name="status" value="1">
                                                                            <button type="submit" class="custom-button">
                                                                                <h1><i class="fe fe-bookmark"></i></h1>
                                                                                <small>Save</small>
                                                                            </button>
                                                                        </form>
                                                                    </span>
                                                                @elseif($saved_post->status == 1)
                                                                    <span>
                                                                        <form action="{{route('save.post')}}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                            <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                            <input type="hidden" name="status" value="0">
                                                                            <button type="submit" class="custom-button text-success">
                                                                                <h1><i class="fe fe-bookmark"></i></h1>
                                                                                <small>Saved</small>
                                                                            </button>
                                                                        </form>
                                                                    </span>
                                                                @endif
                                                            @else
                                                                <span>
                                                                    <form action="{{route('save.post')}}" method="POST">
                                                                        @csrf
                                                                        <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                        <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                        <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                        <input type="hidden" name="status" value="1">
                                                                        <button type="submit" class="custom-button">
                                                                            <h1><i class="fe fe-bookmark"></i></h1>
                                                                            <small>Save</small>
                                                                        </button>
                                                                    </form>
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr>
                                                <form class="mt-1" action="{{route('reply.comment')}}" method="POST">
                                                    @csrf
                                                    <div class="row">
                                                        <div class="col-auto">
                                                            <div class="avatar avatar-sm">
                                                                {{-- <img src="{{Auth::user()->photo}}" alt="{{Auth::user()->name}}" class="avatar-img rounded-circle"> --}}
                                                                @if(Auth::user()->photo)
                                                                    <img src="{{Auth::user()->photo}}" class="avatar-img rounded-circle" alt="{{Auth::user()->name}}">
                                                                    @else
                                                                    <div class="initials">
                                                                        <span>{{Str::limit(Auth::user()->name, 1, '')}}{{Str::limit(Auth::user()->surname, 1, '')}}</span>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="col ms-n2">
                                                            <label class="visually-hidden">Leave a comment...</label>
                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                            <textarea name="comment_reply_body" id="commentReply{{$comment->id}}" class="form-control form-control-flush" onkeyup="commentPost('commentReply{{$comment->id}}', 'commentReplyBtn{{$comment->id}}')" data-autosize rows="1" placeholder="Leave a comment"></textarea>
                                                        </div>
                                                        <div class="col-auto align-self-end">
                                                            <div class="text-muted mb-2">
                                                                <button type="submit" disabled id="commentReplyBtn{{$comment->id}}" name="reply" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white btn-primary">
                                                                    <span class="button__text"><i class="mdi mdi-check"></i> Comment</span>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            @endif
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                            @else
                            <div class="card">
                                <div class="card-body">
                                    <div class="mt-3 mb-3">
                                        <div class="row align-items-center text-center">
                                            <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> No post found</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-header-title">
                                    Recent Files
                                </h4>
                            </div>
                            <div class="card-body">
                                @if(Auth::user()->id == $team->user_id)
                                    <div class="list-group list-group-flush my-n3">
                                        @if(count($shared_files) > 0)
                                            @foreach($shared_files as $shared_file)
                                                @if($shared_file->file_type == 'PDF')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->pdf_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->pdf_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @elseif($shared_file->file_type == 'DOC')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->doc_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->doc_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @elseif($shared_file->file_type == 'ZIP')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->zip_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->zip_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @elseif($shared_file->file_type == 'RAR')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->rar_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->rar_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif
                                            @endforeach
                                            @else
                                            <div class="row align-items-center text-center">
                                                <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> There are no files</h4>
                                            </div>
                                        @endif
                                    </div>
                                    @else
                                    @if(empty($send_request))
                                        <div class="text-center m-6">
                                            <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                            <div class="col-auto mt-2">
                                                <form action="{{route('send.request')}}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="send_request" value="1">
                                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                                    <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                                    <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                                        <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        @elseif($send_request->send_request == 0)
                                        <div class="text-center m-6">
                                            <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                            <div class="col-auto mt-2">
                                                <form action="{{route('send.request')}}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="send_request" value="1">
                                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                                    <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                                    <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                                        <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        @elseif($send_request->send_request == 1 && $send_request->approve_request == 0)
                                        <div class="text-center m-6">
                                            <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                            <div class="col-auto mt-2">
                                                <a style="cursor: not-allowed; text-align: center" class="px-5 bg-padding py-3 d-block d-md-inline-block font-medium leading-5 text-gray-400 transition-colors duration-150 bg-gray-100 hover:bg-gray-100 dark:bg-gray-700 border border-transparent rounded-lg">Request Sent</a>
                                            </div>
                                        </div>
                                        @elseif($send_request->send_request == 1 && $send_request->approve_request == 1)
                                        <div class="list-group list-group-flush my-n3">
                                            @if(count($shared_files) > 0)
                                                @foreach($shared_files as $shared_file)
                                                    @if($shared_file->file_type == 'PDF')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->pdf_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->pdf_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        @elseif($shared_file->file_type == 'DOC')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->doc_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->doc_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        @elseif($shared_file->file_type == 'ZIP')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->zip_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->zip_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        @elseif($shared_file->file_type == 'RAR')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->rar_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->rar_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endif
                                                @endforeach
                                                @else
                                                <div class="row align-items-center text-center">
                                                    <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> There are no files</h4>
                                                </div>
                                            @endif
                                        </div>
                                    @endif
                                @endif
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-header-title">
                                    Members
                                </h4>
                            </div>
                            <div class="card-body">
                                <div class="list-group list-group-flush my-n3">
                                    @if($some_approved_members)
                                        @foreach ($some_approved_members as $some_approved_member)
                                            <div class="list-group-item">
                                                <div class="row align-items-center">
                                                    <div class="col-auto">
                                                        <span class="avatar avatar-sm">
                                                            <?php $user = App\Models\User::where('id', $some_approved_member->user_id)->first(); ?>
                                                            @if($user->photo)
                                                                <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                                @else
                                                                <div class="initials">
                                                                    <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                                </div>
                                                            @endif
                                                        </span>
                                                    </div>
                                                    <div class="col ms-n2">
                                                        <h4 class="mb-1">
                                                            <a href="{{route('user.profile', $user->id)}}">{{$user->name}}</a>
                                                        </h4>
                                                        @php
                                                            $last_seen = strtotime($user->last_seen); //get last_seen from database and convert to numbers
                                                            $now = \Carbon\Carbon::now(); // get current date and time
                                                            $get_now = strtotime($now); // convert current date and time to numbers
                                                            $subtract_now = strtotime("-2 min", $get_now); //subtract 2mins from current date and time
                                                            $final = $get_now - $subtract_now; //get exactly 2mins which is 120seconds
                                                            $get_seen = $get_now - $last_seen; // get the difference between the last seen date and current date, if it is less than 2mins keep online if not keep offline
                                                        @endphp
                                                        <p class="card-text small">
                                                            @if($get_seen <= $final)
                                                                <span class="text-success">●</span> Online
                                                                @else
                                                                <span class="text-secondary">●</span> Offline
                                                            @endif
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                        @else
                                        <div class="text-center mt-4">
                                            <h3 class="text-muted"><i class="fe fe-users"></i> No members</h3>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="saved" role="tabpanel" aria-labelledby="saved-tab">
                <div class="row">
                    <div class="col-12 col-xl-8">
                        @if(count($saved_posts) > 0)
                            @foreach($saved_posts as $saved_post)
                                @php
                                    $comment = App\Models\Comment::where('id', $saved_post->comment_id)->first();
                                @endphp
                                <div class="card">
                                    <div class="card-body">
                                        <div class="mb-3">
                                            <div class="row align-items-center">
                                                <div class="col-auto">
                                                    <span class="avatar avatar-sm">
                                                        <?php $user = App\Models\User::where('id', $comment->user_id)->first(); ?>
                                                        @if($user->photo)
                                                            <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                            @else
                                                            <div class="initials">
                                                                <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                            </div>
                                                        @endif
                                                    </span>
                                                </div>
                                                <div class="col ms-n2">
                                                    <h4 class="mb-1">
                                                        <a href="{{route('user.profile', $user->id)}}">
                                                            {{$user->name}}
                                                        </a>
                                                    </h4>
                                                   <p class="card-text small text-muted">
                                                       <span class="fe fe-clock"></span>
                                                       @if($comment->created_at < $comment->updated_at)
                                                            Edited {{\Carbon\Carbon::parse($comment->updated_at)->toFormattedDateString()}}
                                                            @else
                                                            Posted {{\Carbon\Carbon::parse($comment->created_at)->toFormattedDateString()}}
                                                        @endif
                                                    </p>
                                                </div>
                                                <div class="col-auto">
                                                    @if($comment->user_id == Auth::user()->id)
                                                        @if(empty($comment->article_id))
                                                            <div class="dropdown">
                                                                <a href="#" class="dropdown-ellipses dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                    <i class="fe fe-more-vertical"></i>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a style="cursor: pointer" data-bs-toggle="modal" onclick='showEditPost("{{$comment->comment_body}}", "{{$comment->id}}")' class="dropdown-item">
                                                                        <i class="mdi mdi-pencil mr-2"></i> Edit
                                                                    </a>
                                                                    <form action="/admin/teams/comment/{{$comment->id}}" method="POST">
                                                                        {{ csrf_field() }}
                                                                        {{ method_field('DELETE') }}
                                                                        <button type="submit" name="submit" onclick="return deletePost();" class="dropdown-item">
                                                                            <i class="fe fe-trash mr-2"></i>Delete
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        @endif
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <p class="mb-4">
                                            @if($comment->article_id)
                                                @php
                                                    $body = json_decode($comment->comment_body)
                                                @endphp
                                                <p>{!! $body[0] !!}</p>
                                                <p>{!! $body[1] !!}</p>
                                                <p><a href="{{$body[2]}}" class="text-color"><u>View full article <i class="fe fe-arrow-right"></i></u></a></p>
                                            @elseif($comment->form_precedence_id)
                                                @php
                                                    $body = json_decode($comment->comment_body)
                                                @endphp
                                                <p>{!! $body[0] !!}</p>
                                                <p>{!! $body[1] !!}</p>
                                                <p><a href="{{$body[2]}}" class="text-color"><u>View full form <i class="fe fe-arrow-right"></i></u></a></p>
                                            @else
                                                {!! $comment->comment_body !!}
                                            @endif
                                        </p>
                                        <p class="mb-4 text-center">
                                            @if($send_request)
                                                @if($send_request->send_request == 1 && $send_request->approve_request == 1)
                                                    @if($comment->file_type == 'image')
                                                        <img src="{{$comment->file}}" class="img-fluid rounded">
                                                        @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                        @elseif($comment->file_type == 'PDF')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                                {{$comment->pdf_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'DOC')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                                {{$comment->doc_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'ZIP')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                                {{$comment->zip_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'RAR')
                                                        <div class="comment-body">
                                                            <a class="w-full" href="{{$comment->file}}">
                                                                <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                                {{$comment->rar_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    @endif
                                                    @else
                                                    @if($comment->file_type == 'image')
                                                        <img src="{{$comment->file}}" class="img-fluid rounded">
                                                        @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                        @elseif($comment->file_type == 'PDF')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                                {{$comment->pdf_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'DOC')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                                {{$comment->doc_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'ZIP')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                                {{$comment->zip_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                        @elseif($comment->file_type == 'RAR')
                                                        <div class="comment-body">
                                                            <a class="w-full cursor" onclick="info()">
                                                                <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                                {{$comment->rar_name}}
                                                                <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                    <i class="fe fe-download mx-2"></i>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    @endif
                                                @endif
                                                @else
                                                @if($comment->file_type == 'image')
                                                    <img src="{{$comment->file}}" class="img-fluid rounded">
                                                    @elseif($comment->file_type == 'video')
                                                        <video controls class="rounded w-100">
                                                            <source src="{{$comment->file}}" type="video/mp4">
                                                        </video>
                                                    @elseif($comment->file_type == 'PDF')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->pdf_name}}">
                                                            {{$comment->pdf_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'DOC')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->doc_name}}">
                                                            {{$comment->doc_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'ZIP')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->zip_name}}">
                                                            {{$comment->zip_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    @elseif($comment->file_type == 'RAR')
                                                    <div class="comment-body">
                                                        <a class="w-full cursor" onclick="info()">
                                                            <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$comment->rar_name}}">
                                                            {{$comment->rar_name}}
                                                            <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                <i class="fe fe-download mx-2"></i>
                                                            </span>
                                                        </a>
                                                    </div>
                                                @endif
                                            @endif
                                        </p>
                                        @foreach($comment->comment_replies as $comment_reply)
                                            <div class="comment mt-4 mb-4">
                                                <div class="row">
                                                    <div class="col-auto">
                                                        <span class="avatar avatar-sm">
                                                            <?php $user = App\Models\User::where('id', $comment_reply->user_id)->first(); ?>
                                                            @if($user->photo)
                                                                <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                                @else
                                                                <div class="initials">
                                                                    <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                                </div>
                                                            @endif
                                                        </span>
                                                    </div>
                                                    <div class="col ms-n2">
                                                        <div class="comment-body">
                                                            <div class="row">
                                                                <div class="col">
                                                                    <h5 class="comment-title">
                                                                        <a href="{{route('user.profile', $user->id)}}">
                                                                            {{$user->name}}
                                                                        </a>
                                                                    </h5>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <time class="comment-time">
                                                                        {{\Carbon\Carbon::parse($comment_reply->created_at)->toFormattedDateString()}}
                                                                    </time>
                                                                </div>
                                                            </div>
                                                            <p class="comment-text">
                                                                {{$comment_reply->comment_reply_body}}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                        @if($send_request)
                                            @if($send_request->send_request == 1 && $send_request->approve_request == 1)
                                                <div class="row justify-content-between">
                                                    <div class="col">
                                                        <div class="d-flex">
                                                            <span class="mr-4">
                                                                <form id="like-form">
                                                                    <input type="hidden" name="user_id" id="user-id" value="{{Auth::user()->id}}">
                                                                    <input type="hidden" name="comment_id" id="comment-id" value="{{$comment->id}}">
                                                                    <input type="hidden" name="team_id" id="team-id" value="{{$team->id}}">
                                                                    @php
                                                                        $likes = App\Models\Like::where('comment_id', $comment->id)->get();
                                                                        $user_has_liked = App\Models\Like::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->where('like', 1)->first();
                                                                        $user_has_unliked = App\Models\Like::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->where('like', 0)->first();
                                                                        $user_has_not_liked = App\Models\Like::where('comment_id', $comment->id)->first();
                                                                        $like_count = App\Models\Like::where('comment_id', $comment->id)->where('like', 1)->count();
                                                                    @endphp
                                                                    @if(count($likes) > 0)
                                                                        @if($user_has_liked)
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" id="savedunlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" style="display: none" id="savedlike-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        @elseif($user_has_unliked)
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="savedlike-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="savedunlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        @elseif($user_has_not_liked)
                                                                            <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="savedlike-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                            <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="savedunlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        @endif
                                                                    @else
                                                                        <h1 class="cursor-pointer"><i class="mdi like mdi-heart-outline font-md" id="savedlike-btn{{$comment->id}}" onclick="like('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                        <h1 class="cursor-pointer"><i class="mdi unlike mdi-heart font-md text-red" style="display: none" id="savedunlike-btn{{$comment->id}}" onclick="unLike('{{$like_count}}', 'savedunlike-btn{{$comment->id}}', 'savedlike-btn{{$comment->id}}', 'savedlike-div{{$comment->id}}', 'savedlike-no{{$comment->id}}', '{{$comment->id}}', '{{Auth::user()->id}}', '{{$team->id}}')"></i></h1>
                                                                    @endif
                                                                </form>
                                                                <span id="savedlike-div{{$comment->id}}">
                                                                    <small id="savedlike-no{{$comment->id}}" class="text-color">{{$like_count}}</small>
                                                                </span>
                                                            </span>
                                                            <span class="mr-4">
                                                                <h1><i class="mdi mdi-comment-text-multiple"></i></h1>
                                                                @php
                                                                    $comment_reply_count = App\Models\CommentReply::where('comment_id', $comment->id)->count();
                                                                @endphp
                                                                <small class="text-pink">{{$comment_reply_count}}</small>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto">
                                                        <div class="d-flex text-end">
                                                            @php
                                                                $saved_post = App\Models\SavedPost::where('comment_id', $comment->id)->where('user_id', Auth::user()->id)->first();
                                                            @endphp
                                                            @if(isset($saved_post) && !empty($saved_post))
                                                                @if($saved_post->status == 0)
                                                                    <span>
                                                                        <form action="{{route('save.post')}}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                            <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                            <input type="hidden" name="status" value="1">
                                                                            <button type="submit" name="unpin_post" class="custom-button">
                                                                                <h1><i class="fe fe-bookmark"></i></h1>
                                                                                <small>Save</small>
                                                                            </button>
                                                                        </form>
                                                                    </span>
                                                                @elseif($saved_post->status == 1)
                                                                    <span>
                                                                        <form action="{{route('save.post')}}" method="POST">
                                                                            @csrf
                                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                            <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                            <input type="hidden" name="status" value="0">
                                                                            <button type="submit" class="custom-button text-success">
                                                                                <h1><i class="fe fe-bookmark"></i></h1>
                                                                                <small>Saved</small>
                                                                            </button>
                                                                        </form>
                                                                    </span>
                                                                @endif
                                                            @else
                                                                <span>
                                                                    <form action="{{route('save.post')}}" method="POST">
                                                                        @csrf
                                                                        <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                                        <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                                        <input type="hidden" name="team_id" value="{{$team->id}}">
                                                                        <input type="hidden" name="status" value="1">
                                                                        <button type="submit" class="custom-button">
                                                                            <h1><i class="fe fe-bookmark"></i></h1>
                                                                            <small>Save</small>
                                                                        </button>
                                                                    </form>
                                                                </span>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr>
                                                <form class="mt-1" action="{{route('reply.comment')}}" method="POST">
                                                    @csrf
                                                    <div class="row">
                                                        <div class="col-auto">
                                                            <div class="avatar avatar-sm">
                                                                {{-- <img src="{{Auth::user()->photo}}" alt="{{Auth::user()->name}}" class="avatar-img rounded-circle"> --}}
                                                                @if(Auth::user()->photo)
                                                                    <img src="{{Auth::user()->photo}}" class="avatar-img rounded-circle" alt="{{Auth::user()->name}}">
                                                                    @else
                                                                    <div class="initials">
                                                                        <span>{{Str::limit(Auth::user()->name, 1, '')}}{{Str::limit(Auth::user()->surname, 1, '')}}</span>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="col ms-n2">
                                                            <label class="visually-hidden">Leave a comment...</label>
                                                            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                            <input type="hidden" name="comment_id" value="{{$comment->id}}">
                                                            <textarea name="comment_reply_body" id="savedCommentReply{{$comment->id}}" class="form-control form-control-flush" onkeyup="commentPost('savedCommentReply{{$comment->id}}', 'savedCommentReplyBtn{{$comment->id}}')" data-autosize rows="1" placeholder="Leave a comment"></textarea>
                                                        </div>
                                                        <div class="col-auto align-self-end">
                                                            <div class="text-muted mb-2">
                                                                <button type="submit" disabled id="savedCommentReplyBtn{{$comment->id}}" name="reply" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white btn-primary">
                                                                    <span class="button__text"><i class="mdi mdi-check"></i> Comment</span>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            @endif
                                        @endif
                                    </div>
                                </div>
                            @endforeach
                            @else
                            <div class="card">
                                <div class="card-body">
                                    <div class="mt-3 mb-3">
                                        <div class="row align-items-center text-center">
                                            <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> You have no saved post</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-header-title">
                                    Recent Files
                                </h4>
                            </div>
                            <div class="card-body">
                                @if(Auth::user()->id == $team->user_id)
                                    <div class="list-group list-group-flush my-n3">
                                        @if(count($shared_files) > 0)
                                            @foreach($shared_files as $shared_file)
                                                @if($shared_file->file_type == 'PDF')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->pdf_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->pdf_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @elseif($shared_file->file_type == 'DOC')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->doc_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->doc_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @elseif($shared_file->file_type == 'ZIP')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->zip_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->zip_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    @elseif($shared_file->file_type == 'RAR')
                                                    <div class="list-group-item">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->rar_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1">
                                                                    <a href="{{$shared_file->file}}">{{$shared_file->rar_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_file->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endif
                                            @endforeach
                                            @else
                                            <div class="row align-items-center text-center">
                                                <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> There are no files</h4>
                                            </div>
                                        @endif
                                    </div>
                                    @else
                                    @if(empty($send_request))
                                        <div class="text-center m-6">
                                            <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                            <div class="col-auto mt-2">
                                                <form action="{{route('send.request')}}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="send_request" value="1">
                                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                                    <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                                    <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                                        <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        @elseif($send_request->send_request == 0)
                                        <div class="text-center m-6">
                                            <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                            <div class="col-auto mt-2">
                                                <form action="{{route('send.request')}}" method="POST">
                                                    @csrf
                                                    <input type="hidden" name="send_request" value="1">
                                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                                    <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                                    <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                                        <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                        @elseif($send_request->send_request == 1 && $send_request->approve_request == 0)
                                        <div class="text-center m-6">
                                            <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                            <div class="col-auto mt-2">
                                                <a style="cursor: not-allowed; text-align: center" class="px-5 bg-padding py-3 d-block d-md-inline-block font-medium leading-5 text-gray-400 transition-colors duration-150 bg-gray-100 hover:bg-gray-100 dark:bg-gray-700 border border-transparent rounded-lg">Request Sent</a>
                                            </div>
                                        </div>
                                        @elseif($send_request->send_request == 1 && $send_request->approve_request == 1)
                                        <div class="list-group list-group-flush my-n3">
                                            @if(count($shared_files) > 0)
                                                @foreach($shared_files as $shared_file)
                                                    @if($shared_file->file_type == 'PDF')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->pdf_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->pdf_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        @elseif($shared_file->file_type == 'DOC')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->doc_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->doc_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        @elseif($shared_file->file_type == 'ZIP')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->zip_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->zip_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        @elseif($shared_file->file_type == 'RAR')
                                                        <div class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_file->rar_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1">
                                                                        <a href="{{$shared_file->file}}">{{$shared_file->rar_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_file->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_file->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endif
                                                @endforeach
                                                @else
                                                <div class="row align-items-center text-center">
                                                    <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> There are no files</h4>
                                                </div>
                                            @endif
                                        </div>
                                    @endif
                                @endif
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-header-title">
                                    Members
                                </h4>
                            </div>
                            <div class="card-body">
                                <div class="list-group list-group-flush my-n3">
                                    @if($some_approved_members)
                                        @foreach ($some_approved_members as $some_approved_member)
                                            <div class="list-group-item">
                                                <div class="row align-items-center">
                                                    <div class="col-auto">
                                                        <span class="avatar avatar-sm">
                                                            <?php $user = App\Models\User::where('id', $some_approved_member->user_id)->first(); ?>
                                                            @if($user->photo)
                                                                <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                                @else
                                                                <div class="initials">
                                                                    <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                                </div>
                                                            @endif
                                                        </span>
                                                    </div>
                                                    <div class="col ms-n2">
                                                        <h4 class="mb-1">
                                                            <a href="{{route('user.profile', $user->id)}}">{{$user->name}}</a>
                                                        </h4>
                                                        @php
                                                            $last_seen = strtotime($user->last_seen); //get last_seen from database and convert to numbers
                                                            $now = \Carbon\Carbon::now(); // get current date and time
                                                            $get_now = strtotime($now); // convert current date and time to numbers
                                                            $subtract_now = strtotime("-2 min", $get_now); //subtract 2mins from current date and time
                                                            $final = $get_now - $subtract_now; //get exactly 2mins which is 120seconds
                                                            $get_seen = $get_now - $last_seen; // get the difference between the last seen date and current date, if it is less than 2mins keep online if not keep offline
                                                        @endphp
                                                        <p class="card-text small">
                                                            @if($get_seen <= $final)
                                                                <span class="text-success">●</span> Online
                                                                @else
                                                                <span class="text-secondary">●</span> Offline
                                                            @endif
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                        @else
                                        <div class="text-center mt-4">
                                            <h3 class="text-muted"><i class="fe fe-users"></i> No members</h3>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="members" role="tabpanel" aria-labelledby="members-tab">
                <div class="row">
                    <div class="col-12 col-xl-8">
                        <div class="row">
                            <div class="col-12">
                                <div class="card" data-list='{"valueNames": ["item-name"], "page": 10, "pagination": {"paginationClass": "list-pagination"}}' id="contactsList">
                                    <div class="card-header">
                                        <form>
                                            <div class="input-group input-group-flush input-group-merge input-group-reverse">
                                                <input class="form-control list-search" type="search" placeholder="Search">
                                                <div class="input-group-text">
                                                    <span class="fe fe-search"></span>
                                                </div>
                                            </div>
                                        </form>
                                        @if(Auth::user()->id == $team->user_id)
                                            <div class="col-auto">
                                                <a href="#" data-bs-toggle="modal" data-bs-target="#add_member" id="kt_toolbar_primary_button" class="text-color">
                                                   <i class="fe fe-plus"></i> Add members
                                                </a>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="card-body">
                                        @if(Auth::user()->id == $team->user_id)
                                            @if($approved_members)
                                                <ul id="table_data" class="list-group table_data list-group-lg list-group-flush list my-n4">
                                                    @foreach($approved_members as $approved_member)
                                                        <li class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <?php $user = App\Models\User::where('id', $approved_member->user_id)->first(); ?>
                                                                    <a href="{{route('user.profile', $user->id)}}" class="avatar avatar-lg">
                                                                        @if($user->photo)
                                                                            <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                                            @else
                                                                            <div class="initials">
                                                                                <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                                            </div>
                                                                        @endif
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1 item-name">
                                                                        <a href="{{route('user.profile', $user->id)}}">{{$user->name}}</a>
                                                                    </h4>
                                                                    {{-- <?php $online_user = App\Models\User::select("*")->whereNotNull('last_seen')->first();?>
                                                                    <p class="card-text small">
                                                                        @if(Illuminate\Support\Facades\Cache::has('user-is-online-' . $online_user->id))
                                                                            <span class="text-success">●</span> Online
                                                                            @else
                                                                            <span class="text-secondary">●</span> Offline
                                                                        @endif
                                                                    </p> --}}
                                                                    @php
                                                                        $last_seen = strtotime($user->last_seen); //get last_seen from database and convert to numbers
                                                                        $now = \Carbon\Carbon::now(); // get current date and time
                                                                        $get_now = strtotime($now); // convert current date and time to numbers
                                                                        $subtract_now = strtotime("-2 min", $get_now); //subtract 2mins from current date and time
                                                                        $final = $get_now - $subtract_now; //get exactly 2mins which is 120seconds
                                                                        $get_seen = $get_now - $last_seen; // get the difference between the last seen date and current date, if it is less than 2mins keep online if not keep offline
                                                                    @endphp
                                                                    <p class="card-text small">
                                                                        @if($get_seen <= $final)
                                                                            <span class="text-success">●</span> Online
                                                                            @else
                                                                            <span class="text-secondary">●</span> Offline
                                                                        @endif
                                                                    </p>
                                                                </div>
                                                                @if($approved_member->user_id !== $team->user_id)
                                                                    <div class="col-auto">
                                                                        <form action="/admin/teams/remove/{{$approved_member->id}}" method="POST">
                                                                            {{ csrf_field() }}
                                                                            {{ method_field('DELETE') }}
                                                                            <button type="submit" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white w-100 btn-primary">
                                                                                <span class="button__text"><i class="mdi mdi-close"></i> Remove</span>
                                                                            </button>
                                                                        </form>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                                @else
                                                <div class="text-center mt-8 mb-8">
                                                    <h3 class="text-muted"><i class="fe fe-users"></i> There are currently no members</h3>
                                                    <div class="col-auto mt-2">
                                                        <a href="#" class="btn btn-primary text-white" data-bs-toggle="modal" data-bs-target="#add_member" id="kt_toolbar_primary_button" class="btn btn-primary lift">
                                                            <i class="fe fe-plus"></i> Add members
                                                        </a>
                                                    </div>
                                                </div>
                                            @endif
                                            @else
                                            @if($approved_members)
                                                <ul id="table_data" class="list-group table_data list-group-lg list-group-flush list my-n4">
                                                    @foreach($approved_members as $approved_member)
                                                        <li class="list-group-item">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <span class="avatar avatar-sm">
                                                                        <?php $user = App\Models\User::where('id', $approved_member->user_id)->first(); ?>
                                                                        @if($user->photo)
                                                                            <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                                                            @else
                                                                            <div class="initials">
                                                                                <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                                                            </div>
                                                                        @endif
                                                                    </span>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1 name">
                                                                        <a href="{{route('user.profile', $user->id)}}">{{$user->name}}</a>
                                                                    </h4>
                                                                    {{-- <?php $online_user = App\Models\User::select("*")->whereNotNull('last_seen')->first();?>
                                                                    <p class="card-text small">
                                                                        @if(Illuminate\Support\Facades\Cache::has('user-is-online-' . $online_user->id))
                                                                            <span class="text-success">●</span> Online
                                                                            @else
                                                                            <span class="text-secondary">●</span> Offline
                                                                        @endif
                                                                    </p> --}}
                                                                    @php
                                                                        $last_seen = strtotime($user->last_seen); //get last_seen from database and convert to numbers
                                                                        $now = \Carbon\Carbon::now(); // get current date and time
                                                                        $get_now = strtotime($now); // convert current date and time to numbers
                                                                        $subtract_now = strtotime("-2 min", $get_now); //subtract 2mins from current date and time
                                                                        $final = $get_now - $subtract_now; //get exactly 2mins which is 120seconds
                                                                        $get_seen = $get_now - $last_seen; // get the difference between the last seen date and current date, if it is less than 2mins keep online if not keep offline
                                                                    @endphp
                                                                    <p class="card-text small">
                                                                        @if($get_seen <= $final)
                                                                            <span class="text-success">●</span> Online
                                                                            @else
                                                                            <span class="text-secondary">●</span> Offline
                                                                        @endif
                                                                    </p>
                                                                </div>
                                                                @if($approved_member->user_id == auth()->id())
                                                                    <div class="col-auto">
                                                                        <form action="/admin/teams/leave/{{$approved_member->id}}" method="POST">
                                                                            {{ csrf_field() }}
                                                                            {{ method_field('DELETE') }}
                                                                            <button type="submit" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white w-100 btn-primary">
                                                                                <span class="button__text"><i class="mdi mdi-close"></i> Leave</span>
                                                                            </button>
                                                                        </form>
                                                                    </div>
                                                                @endif
                                                            </div>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                                @else
                                                <div class="text-center mt-8 mb-8">
                                                    <h3 class="text-muted"><i class="fe fe-users"></i> There are currently no members</h3>
                                                    <div class="col-auto mt-2">
                                                        <a href="#" class="btn btn-primary text-white" data-bs-toggle="modal" data-bs-target="#add_member" id="kt_toolbar_primary_button" class="btn btn-primary lift">
                                                            <i class="fe fe-plus"></i> Add members
                                                        </a>
                                                    </div>
                                                </div>
                                            @endif
                                        @endif
                                    </div>
                                    <div class="row g-0">
                                        <ul class="col list-pagination-prev pagination pagination-tabs justify-content-start">
                                            <li class="page-item">
                                                <a class="page-link" href="#">
                                                <i class="fe fe-arrow-left me-1"></i> Prev
                                                </a>
                                            </li>
                                        </ul>
                                        <ul class="col list-pagination pagination pagination-tabs justify-content-center"></ul>
                                        <ul class="col list-pagination-next pagination pagination-tabs justify-content-end">
                                            <li class="page-item">
                                                <a class="page-link" href="#">
                                                Next <i class="fe fe-arrow-right ms-1"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="list-group list-group-flush my-n3">
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h5 class="mb-0">
                                                    Member Count
                                                </h5>
                                            </div>
                                            <div class="col-auto">
                                                <small class="text-muted">
                                                    {{$approved_member_count}}
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h5 class="mb-0">
                                                    Created
                                                </h5>
                                            </div>
                                            <div class="col-auto">
                                                <small class="text-muted">
                                                    {{\Carbon\Carbon::parse($team->created_at)->toFormattedDateString()}}
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                    @if($team->user_id == Auth::user()->id)
                                        <div class="list-group-item">
                                            <div class="row align-items-center">
                                                <div class="col">
                                                    <h5 class="mb-0 text-color">
                                                        Approve new members
                                                    </h5>
                                                </div>
                                                <div class="col-auto">
                                                    <small class="text-success">
                                                        <a href="{{route('approve.member', $team->id)}}" class="text-green"><i class="mdi mdi-check"></i>Approve</a>
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h5 class="mb-0">
                                                    Team Owner
                                                </h5>
                                            </div>
                                            <div class="col-auto">
                                                <small class="text-muted">
                                                    {{$team->team_owner}}
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="review" role="tabpanel" aria-labelledby="comment-tab">
                @if(count($reviews) > 0)
                    @foreach($reviews as $review)
                        <div class="mb-3">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <span class="avatar avatar-sm">
                                        <?php $user = App\Models\User::where('id', $review->user_id)->first(); ?>
                                        @if($user->photo)
                                            <img src="{{$user->photo}}" class="avatar-img rounded-circle" alt="{{$user->name}}">
                                            @else
                                            <div class="initials">
                                                <span>{{Str::limit($user->name, 1, '')}}{{Str::limit($user->surname, 1, '')}}</span>
                                            </div>
                                        @endif
                                    </span>
                                </div>
                                <div class="col ms-n2">
                                    <h4 class="mb-1">
                                        <a href="{{route('user.profile', $user->id)}}">
                                            {{$user->name}}
                                        </a>
                                    </h4>
                                    <p class="card-text small text-muted">
                                        {{getRating($review->rating)}} . {{\Carbon\Carbon::parse($review->created_at)->toFormattedDateString()}}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <p class="mb-4">
                            {!! $review->review !!}
                        </p>
                        <hr class="my-4">
                    @endforeach
                @else
                    <div class="mt-3 mb-3">
                        <div class="row align-items-center text-center">
                            <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> No review</h4>
                        </div>
                    </div>
                @endif
            </div>
            <div class="tab-pane fade" id="resources" role="tabpanel" aria-labelledby="resources-tab">
                <div data-list='{"valueNames": ["name"]}'>
                    <div class="" data-list='{"valueNames": ["name"], "listClass": "listAlias"}'>
                        <div class="row mb-4">
                            <div class="col">
                                <form>
                                    <div class="input-group input-group-lg input-group-merge input-group-reverse">
                                        <input class="form-control list-search" type="text" placeholder="Search for resources or files" style="height: 50px">
                                        <div class="input-group-text">
                                            <span class="fe fe-search"></span>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row list">
                            @if(Auth::user()->id == $team->user_id)
                                @if(count($shared_resources) > 0)
                                    @foreach($shared_resources as $shared_resource)
                                        @if($shared_resource->file_type == 'PDF')
                                            <div class="col-12">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->pdf_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1 name">
                                                                    <a href="{{$shared_resource->file}}">{{$shared_resource->pdf_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @elseif($shared_resource->file_type == 'DOC')
                                            <div class="col-12">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->doc_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1 name">
                                                                    <a href="{{$shared_resource->file}}">{{$shared_resource->doc_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @elseif($shared_resource->file_type == 'ZIP')
                                            <div class="col-12">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->zip_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1 name">
                                                                    <a href="{{$shared_resource->file}}">{{$shared_resource->zip_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @elseif($shared_resource->file_type == 'RAR')
                                            <div class="col-12">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="row align-items-center">
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->rar_name}}">
                                                                </a>
                                                            </div>
                                                            <div class="col ms-n2">
                                                                <h4 class="mb-1 name">
                                                                    <a href="{{$shared_resource->file}}">{{$shared_resource->rar_name}}</a>
                                                                </h4>
                                                                <p class="card-text small text-muted">
                                                                    <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                </p>
                                                            </div>
                                                            <div class="col-auto">
                                                                <a href="{{$shared_resource->file}}">
                                                                    <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                        <i class="fe fe-download mx-2"></i>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                    @endforeach
                                    @else
                                    <div class="row align-items-center text-center">
                                        <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> There are no files</h4>
                                    </div>
                                @endif
                                @else
                                @if(empty($send_request))
                                    <div class="text-center m-6">
                                        <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                        <div class="col-auto mt-2">
                                            <form action="{{route('send.request')}}" method="POST">
                                                @csrf
                                                <input type="hidden" name="send_request" value="1">
                                                <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                <input type="hidden" name="team_id" value="{{$team->id}}">
                                                <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                                <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                                    <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    @elseif($send_request->send_request == 0)
                                    <div class="text-center m-6">
                                        <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                        <div class="col-auto mt-2">
                                            <form action="{{route('send.request')}}" method="POST">
                                                @csrf
                                                <input type="hidden" name="send_request" value="1">
                                                <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                                <input type="hidden" name="team_id" value="{{$team->id}}">
                                                <input type="hidden" name="team_owner_id" value="{{$team->user_id}}">
                                                <button type="submit" name="submit" onclick="this.classList.toggle('button--loading')" class="btn text-white btn-primary d-block d-md-inline-block">
                                                    <span class="button__text"><i class="mdi mdi-plus"></i> Request Access</span>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    @elseif($send_request->send_request == 1 && $send_request->approve_request == 0)
                                    <div class="text-center m-6">
                                        <h3 class="text-muted"><i class="i.mdi.mdi-warning"></i> You need to join this team to get access</h3>
                                        <div class="col-auto mt-2">
                                            <a style="cursor: not-allowed; text-align: center" class="px-5 bg-padding py-3 d-block d-md-inline-block font-medium leading-5 text-gray-400 transition-colors duration-150 bg-gray-100 hover:bg-gray-100 dark:bg-gray-700 border border-transparent rounded-lg">Request Sent</a>
                                        </div>
                                    </div>
                                    @elseif($send_request->send_request == 1 && $send_request->approve_request == 1)
                                    @if(count($shared_resources) > 0)
                                        @foreach($shared_resources as $shared_resource)
                                            @if($shared_resource->file_type == 'PDF')
                                                <div class="col-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <img src="{{asset('assets/images/pdf.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->pdf_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1 name">
                                                                        <a href="{{$shared_resource->file}}">{{$shared_resource->pdf_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                @elseif($shared_resource->file_type == 'DOC')
                                                <div class="col-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <img src="{{asset('assets/images/doc.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->doc_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1 name">
                                                                        <a href="{{$shared_resource->file}}">{{$shared_resource->doc_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                @elseif($shared_resource->file_type == 'ZIP')
                                                <div class="col-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <img src="{{asset('assets/images/zip.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->zip_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1 name">
                                                                        <a href="{{$shared_resource->file}}">{{$shared_resource->zip_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                @elseif($shared_resource->file_type == 'RAR')
                                                <div class="col-12">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="row align-items-center">
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <img src="{{asset('assets/images/rar.png')}}" class="h-2 w-2 mr-2" alt="{{$shared_resource->rar_name}}">
                                                                    </a>
                                                                </div>
                                                                <div class="col ms-n2">
                                                                    <h4 class="mb-1 name">
                                                                        <a href="{{$shared_resource->file}}">{{$shared_resource->rar_name}}</a>
                                                                    </h4>
                                                                    <p class="card-text small text-muted">
                                                                        <time datetime="2018-05-24">Shared {{\Carbon\Carbon::parse($shared_resource->created_at)->toFormattedDateString()}}</time>
                                                                    </p>
                                                                </div>
                                                                <div class="col-auto">
                                                                    <a href="{{$shared_resource->file}}">
                                                                        <span class="flex align items text-gray-600 dark:text-gray-300">
                                                                            <i class="fe fe-download mx-2"></i>
                                                                        </span>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach
                                        @else
                                        <div class="row align-items-center text-center">
                                            <h4 class="text-muted"><i class="mdi mdi-file-outline"></i> There are no files</h4>
                                        </div>
                                    @endif
                                @endif
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="settings" role="tabpanel" aria-labelledby="settings-tab">
                <div class="row">
                    <div class="col-12 col-xl-8">
                        <div class="card">
                            <div class="card-body p-5">
                                <form class="tab-content pb-4" id="wizardSteps" action="{{route('settings.team', $team->id)}}" method="POST" enctype="multipart/form-data">
                                    {{ csrf_field() }}
                                    {{ method_field('patch') }}
                                    <div class="form-group">
                                        <label class="form-label">
                                            Team name
                                        </label>
                                        <input type="hidden" name="user_id" value="{{$team->user_id}}">
                                        <input type="hidden" name="team_owner" id="team_owner"value="{{$team->team_owner}}">
                                        <input type="text" name="name" class="form-control" value="{{$team->name}}">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label mb-1">
                                            Team description
                                        </label>
                                        <small class="form-text text-muted">
                                            This is what others will see about your team
                                        </small>
                                        <textarea name="description" id="description" class="form-control" rows="5" placeholder="Enter description">{{$team->description}}</textarea>
                                    </div>
                                    <hr class="mt-4 mb-5">
                                    <div class="form-group">
                                        <label class="form-label mb-1">
                                            Team Cover Image
                                        </label>
                                        <small class="form-text text-muted">
                                            Please use an image no larger than 1200px * 600px.
                                        </small>
                                        <div class="form-group">
                                            <div class="avatar-upload">
                                                <div class="avatar-edit">
                                                    <input type='file' name="photo" id="imageUpload" accept=".png, .jpg, .jpeg" />
                                                    <label for="imageUpload"></label>
                                                </div>
                                                <div class="avatar-preview">
                                                    <div id="imagePreview" style="background-image: url({{$team->photo}})">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white w-100 btn-primary">
                                        <span class="button__text"><i class="mdi mdi-check"></i> Save team</span>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="list-group list-group-flush my-n3">
                                    <div class="list-group-item">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h5 class="mb-0">
                                                    Delete Team
                                                </h5>
                                            </div>
                                            <div class="col-auto">
                                                <form action="/admin/teams/{{$team->id}}" method="POST">
                                                    {{ csrf_field() }}
                                                    {{ method_field('DELETE') }}
                                                    <button type="submit" name="submit" onclick="return deleteFunction();" class="btn text-white btn-danger">
                                                        <i class="fe fe-trash mr-2"></i>Delete
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="add_member" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="fs-1 fw-boldest">Add a member</div>
                    <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            <i class="mdi mdi-close"></i>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y mt-4">
                    <div class="container">
                        <div class="row justify-content-center">
                          <div class="col-12">
                            <form class="tab-content pb-4" id="wizardSteps" action="{{route('send.invite', $team->id)}}" method="POST">
                                @csrf
                                <div class="row justify-content-center">
                                    <div class="text-center">
                                        <p class="mb-5 text-muted">Send invite links to people to join your team</p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">
                                        Email
                                    </label>
                                    <input type="hidden" name="team_id" class="form-control" value="{{$team->id}}">
                                    <input type="email" name="email" class="form-control">
                                </div>
                                <button type="submit" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white w-100 btn-primary">
                                    <span class="button__text"><i class="mdi mdi-message"></i> Send invite</span>
                                </button>
                            </form>
                            <div class="row justify-content-center">
                                <div class="text-center">
                                    <p class="text-muted">OR</p>
                                </div>
                            </div>
                            <a class="btn mb-5 button_load btn-custom w-100">
                                <i class="fe fe-paperclip mr-2"></i><input type="button" class="custom-button" id="hide-copy" value="Copy invite Link" onclick="Copy();" style="margin-top: -8px;">
                                <span class="text-color" id="show-status" style="display: none;">Link copied!</span>
                            </a>
                            <div class="row justify-content-center">
                                <span><input type="text" style="position: absolute; opacity: 0;" id="paste-box"></span>
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="startMeeting" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="fs-1 fw-boldest">Start a Meeting</div>
                    <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            <i class="mdi mdi-close"></i>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y mt-4">
                    <div class="container">
                        <div class="row justify-content-center">
                          <div class="col-12">
                            <div class="row justify-content-center">
                                <div class="text-center">
                                    <p class="mb-5 text-muted">Send meeting link for people to join</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Link
                                </label>
                                <input type="text" class="form-control" id="paste-box1"  value="{{url()->current()}}/meeting">
                            </div>
                            <a class="btn mb-5 button_load btn-custom w-100">
                                <i class="fe fe-paperclip mr-2"></i><input type="button" class="custom-button" id="hide-copy1" value="Copy Meeting Link" onclick="CopyMeeting();" style="margin-top: -8px;">
                                <span class="text-color" id="show-status1" style="display: none;">Link copied!</span>
                            </a>
                            <a href="{{route('team.meeting', $team->id)}}" class="btn button_load text-white w-100 btn-primary">
                               <i class="mdi mdi-radiobox-marked"></i> Start Meeting
                            </a>
                            <div class="my-5">
                            </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="join_team" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="fs-1 fw-boldest">Join this Team</div>
                    <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            <i class="mdi mdi-close"></i>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y mt-4">
                    <div class="container">
                        <div class="row justify-content-center">
                          <div class="col-12">
                            <form class="tab-content pb-4" id="wizardSteps" action="{{route('joined.team', $team->id)}}" method="POST">
                                @csrf
                                <div class="row justify-content-center">
                                    <div class="text-center">
                                        <p class="mb-5 text-muted">You were invited to join {{$team->name}}</p>
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="text-center mb-4">
                                        <img src="{{$team->photo}}" alt="{{$team->name}}" class="card-img-top">
                                    </div>
                                </div>
                                <input type="hidden" name="send_request" value="1">
                                <input type="hidden" name="approve_request" value="1">
                                <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                <input type="hidden" name="team_id" value="{{$team->id}}">
                                <button type="submit" onclick="this.classList.toggle('button--loading')" class="btn button_load text-white w-100 btn-primary">
                                    <span class="button__text"><i class="mdi mdi-check"></i> Join Team</span>
                                </button>
                            </form>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editPost" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="fs-1 fw-boldest">Edit Post</div>
                    <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-2x">
                            <i class="mdi mdi-close"></i>
                        </span>
                    </div>
                </div>
                <div class="modal-body scroll-y mt-4">
                    <div class="container">
                        <div class="row justify-content-center">
                          <div class="col-12">
                            <form action="{{route('update.comment')}}" method="POST">
                                {{ csrf_field() }}
                                {{ method_field('patch') }}
                                <div class="input-group input-group-lg input-group-flush input-group-merge">
                                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                    <input type="hidden" name="team_id" value="{{$team->id}}">
                                    <input type="hidden" name="comment_id" id="comment-id">
                                    <textarea name="comment_body" id="comment-input" class="form-control form-control-flush" data-autosize rows="1" placeholder="Create posts and share files to this team"></textarea>
                                    <div class="input-group-text">
                                        <button type="submit" onclick="this.classList.toggle('button--loading')" id="remove-1" class="btn button_load text-white btn-primary">
                                            <span class="button__text"><i class="mdi mdi-check"></i> Repost</span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="rate" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="height: auto !important">
                <div class="modal-card card" data-list='{"valueNames": ["name"]}'>
                    <div class="card-header">
                        <h4 class="card-header-title" id="exampleModalCenterTitle">
                            Rate this Team
                        </h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group justify-content-center">
                                    <div class="d-flex p-2 text-center justify-content-center">
                                        <div class="mr-3">
                                            <a href="#!" class="cursor-pointer" id="first-star-icon" onclick="first()">
                                                <i class="mdi mdi-star-outline font-50"></i>
                                            </a><br>
                                        </div>
                                        <div class="mr-3">
                                            <a href="#!" class="cursor-pointer" id="second-star-icon" onclick="second()">
                                                <i class="mdi mdi-star-outline font-50"></i>
                                            </a><br>
                                        </div>
                                        <div class="mr-3">
                                            <a href="#!" class="cursor-pointer" id="third-star-icon" onclick="third()">
                                                <i class="mdi mdi-star-outline font-50"></i>
                                            </a><br>
                                        </div>
                                        <div class="mr-3">
                                            <a href="#!" class="cursor-pointer" id="fourth-star-icon" onclick="fourth()">
                                                <i class="mdi mdi-star-outline font-50"></i>
                                            </a><br>
                                        </div>
                                        <div class="">
                                            <a href="#!" class="cursor-pointer" id="fifth-star-icon" onclick="fifth();">
                                                <i class="mdi mdi-star-outline font-50"></i>
                                            </a><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <div class="col-12">
                                <form action="{{route('rate.team')}}" method="POST">
                                    @csrf
                                    <div class="form-group">
                                        <label class="form-label mb-1">
                                            Your review
                                        </label>
                                        <input type="hidden" name="rating" id="rating">
                                        <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                                        <input type="hidden" name="type" value="team">
                                        <input type="hidden" name="review_type" value="rating">
                                        <input type="hidden" name="reference_id" value="{{$team->id}}">
                                        <textarea name="review" id="review-input" class="form-control"></textarea>
                                        <div class="mt-4">
                                            <button type="submit" disabled id="reviewBtn" class="btn button_load text-white w-100 btn-primary" onclick="this.classList.toggle('button--loading')">
                                                <div class="button__text"> Send Review</div>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>

        $(document ).ready(function() {
            @php
            $routeName = request()->route()->named("join.team");
            $join_team = App\Models\UserTeam::where('user_id', Auth::user()->id)->where('send_request', 1)->where('approve_request', 1)->first();
            @endphp
            @if(!$join_team)
                @if(Session::has('join') && Session::get('join') == 1 && $routeName == 'join.team')
                    $('#join_team').modal('show');
                    {{Session::forget('join')}};
                @endif
                @else
                @if($join_team->team_id !== $team->id)
                    @if(Session::has('join') && Session::get('join') == 1 && $routeName == 'join.team')
                        $('#join_team').modal('show');
                        {{Session::forget('join')}};
                    @endif
                @endif
            @endif
        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#imageUpload").change(function() {
            readURL(this);
        });
        function deleteFunction() {
            if(!confirm("Are you sure you want to delete this Team?"))
            event.preventDefault();
        }
        function deletePost() {
            if(!confirm("Are you sure you want to delete this Post?"))
            event.preventDefault();
        }
        const actualBtn = document.getElementById('actual-btn');

        const fileChosen = document.getElementById('file-chosen');

        actualBtn.addEventListener('change', function(){
            fileChosen.textContent = this.files[0].name
        })
        function showFile() {
            document.getElementById('file_input').style.display = 'block';
            document.getElementById('attach').style.display = 'none';
            document.getElementById('remove').style.display = 'block';
            document.getElementById('remove-1').style.display = 'none';
            document.getElementById('show-1').style.display = 'block';
        }
        function removeFile() {
            document.getElementById('file_input').style.display = 'none';
            document.getElementById('attach').style.display = 'block';
            document.getElementById('remove').style.display = 'none';
            document.getElementById('remove').style.display = 'none';
            document.getElementById('remove-1').style.display = 'block';
            document.getElementById('show-1').style.display = 'none';
        }

        function showDiv(PDF, DOC, element)
        {
            document.getElementById(PDF).style.display = element.value == 'PDF' ? 'block' : 'none';
            document.getElementById(DOC).style.display = element.value == 'DOC' ? 'block' : 'none';
            // document.getElementById(ZIP).style.display = element.value == 'ZIP' ? 'block' : 'none';
            // document.getElementById(RAR).style.display = element.value == 'RAR' ? 'block' : 'none';
        }

        function info() {
            swal({
                title: "Sorry!",
                text: "You need to join this team to get access to files",
                icon: "error",
            });
        }

        function showEditPost(comment, id){
            document.getElementById("comment-input").value = comment;
            document.getElementById("comment-id").value = id;
            $('#editPost').modal('show')
        }

        function Copy()
        {
            var Url = document.getElementById("paste-box");
            // Url.value = window.location.href;
            Url.value = "{{route('join.team', $team->id)}}";
            Url.focus();
            Url.select();
            document.execCommand("Copy");

            document.getElementById('hide-copy').style.display = 'none';
            document.getElementById('show-status').style.display = 'inline-block';
        }

        function CopyMeeting()
        {
            var Url = document.getElementById("paste-box1");
            // Url.value = window.location.href;
            Url.value = "{{route('team.meeting', $team->id)}}";
            Url.focus();
            Url.select();
            document.execCommand("Copy");

            document.getElementById('hide-copy1').style.display = 'none';
            document.getElementById('show-status1').style.display = 'inline-block';
        }

        const searchPostBtn = document.getElementById('searchPostBtn')
        const postBtn = document.getElementById('remove-1')
        const postBtn1 = document.getElementById('show-1')

        const searchBar = document.getElementById('searchBar')
        const commentBody = document.getElementById('commentBody')

        const checkSearchButton = () => {
            searchPostBtn.disabled = !(
                searchBar.value
            )
        }
        const checkPostButton = () => {
            postBtn.disabled = !(
                commentBody.value
            )
        }
        const checkPostButton1 = () => {
            postBtn1.disabled = !(
                commentBody.value
            )
        }

        searchBar.addEventListener('change', checkSearchButton)
        commentBody.addEventListener('change', checkPostButton)
        commentBody.addEventListener('change', checkPostButton1)

        function unpin(x) {
            x.innerHTML = '<i class="mdi mdi-pin-off"></i> Unpin post';
            x.classList.remove('text-success');
            x.classList.add('text-color');
        }
        function pin(x) {
            x.innerHTML = '<i class="mdi mdi-pin"></i> Pinned';
            x.classList.remove('text-color');
            x.classList.add('text-success');
        }

        function commentPost(commentBody, commentBtn) {
        $(document).ready(function () {
            var emptyCommentBox = $.trim($("#" + commentBody).val());
            if (emptyCommentBox === "") {
                document.getElementById(commentBtn).disabled = true;
                document.getElementById(commentBtn).style.opacity = 0.3;
                document.getElementById(commentBtn).style.cursor = 'unset';
            } else {
                document.getElementById(commentBtn).disabled = false;
                document.getElementById(commentBtn).style.opacity = 1;
                document.getElementById(commentBtn).style.cursor = 'pointer';
            }
        });
    }
    </script>
    <script>
        // liking team post function
        function like(likeCount, unlikeBtn, likeBtn, likeDiv, likeNo, commentId, userId, teamId) {
            document.getElementById(unlikeBtn).style.display = 'block';
            document.getElementById(unlikeBtn).style.marginTop = '-19px';
            document.getElementById(likeBtn).style.display = 'none';
            if( document.getElementById(likeDiv).style.display = 'none') {
                document.getElementById(likeDiv).style.display = 'block';
                noOfLikes = document.getElementById(likeNo).innerHTML;
                document.getElementById(likeNo).innerHTML = parseInt(noOfLikes) + 1;
            } else {
                noOfLikes = document.getElementById(likeNo).innerHTML;
                document.getElementById(likeNo).innerHTML = parseInt(noOfLikes) + 1;
            }

            let user_id = userId;
            let comment_id = commentId;
            let team_id = teamId;
            let type = 'team';
            let like = 1;

            $.ajax({
                type:'POST',
                url: "{{ url('/admin/teams/post/like')}}",
                data:{
                    "_token": "{{ csrf_token() }}",
                    user_id:user_id,
                    team_id:team_id,
                    comment_id:comment_id,
                    type:type,
                    like:like,
                },
                success:function(data){
                    $("#like-form")[0].reset();
                    console.log(data);
                },
                error: function(error) {
                    console.log(error);
                }
            });
        }

        // unliking team post function
        function unLike(likeCount, unlikeBtn, likeBtn, likeDiv, likeNo, commentId, userId, teamId) {
            document.getElementById(likeBtn).style.display = 'block';
            // document.getElementById(likeBtn).style.marginTop = '-18px';
            document.getElementById(unlikeBtn).style.display = 'none';
            noOfLikes = document.getElementById(likeNo).innerHTML;
            document.getElementById(likeNo).innerHTML = parseInt(noOfLikes) - 1;

            let user_id = userId;
            let comment_id = commentId;
            let team_id = teamId;
            let type = 'team';
            let like = 0;

            $.ajax({
                type:'POST',
                url: "{{ url('/admin/teams/post/like')}}",
                data:{
                    "_token": "{{ csrf_token() }}",
                    user_id:user_id,
                    team_id:team_id,
                    comment_id:comment_id,
                    type:type,
                    like:like,
                },
                success:function(data){
                    $("#like-form")[0].reset();
                    console.log(data);
                },
                error: function(error) {
                    console.log(error);
                }
            });
        }

    </script>
     <script>
        const reviewBtn = document.getElementById('reviewBtn')
        const review = document.getElementById('review-input')
    
        const checkEnableButton = () => {
            reviewBtn.disabled = !(
                review.value
            )
        }
        review.addEventListener('change', checkEnableButton)
    
        function first() {
            document.getElementById("first-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("second-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            document.getElementById("third-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            document.getElementById("fourth-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            document.getElementById("fifth-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            $('#rating').val('1')
        }
        function second() {
            document.getElementById("first-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("second-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("third-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            document.getElementById("fourth-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            document.getElementById("fifth-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            $('#rating').val('2')
        }
        function third() {
            document.getElementById("first-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("second-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("third-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("fourth-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            document.getElementById("fifth-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            $('#rating').val('3')
        }
        function fourth() {
            document.getElementById("first-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("second-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("third-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("fourth-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("fifth-star-icon").innerHTML = '<i class="mdi mdi-star-outline font-50"></i>'
            $('#rating').val('4')
        }
        function fifth() {
            document.getElementById("first-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("second-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("third-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("fourth-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            document.getElementById("fifth-star-icon").innerHTML = '<i class="mdi mdi-star text-yellow font-50"></i>'
            $('#rating').val('5')
        }
    </script>
@endsection
