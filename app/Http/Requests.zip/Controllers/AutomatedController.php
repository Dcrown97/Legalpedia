<?php

namespace App\Http\Controllers;

use App\Models\LicensedUserSession;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Message;
use Illuminate\Http\Request;
use App\Notifications\BirthdayMessage;
use Illuminate\Support\Facades\DB;

class AutomatedController extends Controller
{
    ///////////////////////////////////////send birthday messages to users//////////////////////////////////
    public function birthdayMessage() {
        $users = User::where('dob','<>', null)->get();
        $message = Message::where('type', 'automated')->where('receipient_type', 'dob')->orderBy('created_at', 'DESC')->first();
        if($message) {
            foreach($users as $user) {
                $date = Carbon::now();
                $get_date = strtotime($date);
                $now = date('M d', $get_date);
                $dob = strtotime($user->dob);
                $user_dob = date('M d', $dob);
                if($user_dob == $now) {
                    // $user->notify(new BirthdayMessage($user, $message));
                    $explodedMail =  $user->name .'|' . $user->email;
                    $subject = $message->subject;
                    $newContent =  [
                        'user' => $user->name,
                        'subject' => $message->subject,
                        'body' => $message->body
                    ];
                    $content = view("emails.birthdayMessage", $newContent)->render();
                    tribearcMail($subject, $content, $explodedMail);
                }
            }
            info(['birthday_message_success' => now()->toDayDateTimeString()]);
            return 'Ran successfully';
        }
        info(['birthday_message_error' => now()->toDayDateTimeString()]);
        return 'Couldn\'t run';

    }


    ///////////////////////////////////////Clear license user session//////////////////////////////////
    public function clearSession() {
        DB::table('licensed_user_sessions')->delete();
        info(['license_session_cleared' => now()->toDayDateTimeString()]);
        return 'license session cleared';
    }
}
